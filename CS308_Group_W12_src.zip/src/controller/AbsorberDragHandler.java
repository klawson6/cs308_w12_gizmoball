package controller;

import ModelPackage.GizmoType;
import ModelPackage.IModel;
import javafx.event.EventHandler;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import view.ResizableCanvas;

public class AbsorberDragHandler implements EventHandler<MouseDragEvent> {

    public AbsorberDragHandler(IModel model, ResizableCanvas canvas, ChoiceBox<GizmoType> gizmoChoiceBox) {



    }

    @Override
    public void handle(MouseDragEvent event) {


    }
}
